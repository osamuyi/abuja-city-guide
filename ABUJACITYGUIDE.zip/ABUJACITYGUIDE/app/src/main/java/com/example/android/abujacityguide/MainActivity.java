package com.example.android.abujacityguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Set the content of the activity to use the activity_main. xml layout file
        setContentView(R.layout.activity_main);

        //Find the view that shows the Restaurants/Hotels/Churches/Parks category
        TextView restaurant = (TextView) findViewById(R.id.resBtn);
        //Set a click listener on that view
        restaurant.setOnClickListener(new View.OnClickListener() {
            //The code is this method will be executed when the events view is clicked on
            @Override
            public void onClick(View v) {
                //Create a new intent to open the {@link Events Activity
                Intent resIntent = new Intent(MainActivity.this, RestaurantsActivity.class);
                //Start the new activity
                startActivity(resIntent);
            }
        });

        TextView hotels = (TextView) findViewById(R.id.hotelBtn);
        hotels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent hotelsIntent = new Intent(MainActivity.this, HotelsActivity.class);
                startActivity(hotelsIntent);
            }
        });

        TextView churches = (TextView) findViewById(R.id.churchesBtn);
        churches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent churchesIntent = new Intent(MainActivity.this, ChurchesActivity.class);
                startActivity(churchesIntent);
            }
        });

        TextView parks = (TextView) findViewById(R.id.parksBtn);
        parks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent parksIntent = new Intent(MainActivity.this, ParksActivity.class);
                startActivity(parksIntent);
            }
        });
    }
}
