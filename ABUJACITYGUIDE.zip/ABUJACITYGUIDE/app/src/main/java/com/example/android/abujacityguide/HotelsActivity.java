package com.example.android.abujacityguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class HotelsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_list);

        //Creating a ArrayList: Using String for Hotels
        final ArrayList<Details> detail = new ArrayList<Details>();
        //Elements below should be added to the array list

        /*numberWords.add("one"); detail.add(new Details("Hilton",
        "12, Druman cave, Warsaw Avenue, Maitama"));
         */
        detail.add(new Details("Hilton", "12, Druman cave, Warsaw Avenue, Maitama"));
        detail.add(new Details("Radisson Blu", "Plot, Runnings way, Jabi Lake"));
        detail.add(new Details("The Oriental Hotel", "122A, Games Village, Duport"));
        detail.add(new Details("The Sounthern Sun", "120, Peace Drive, Jack White Avenue, Wuse 2"));
        detail.add(new Details("Four Points Sheraton", "12, DreadStyle Avenue, Flow Streak"));

        DetailsAdapter adapter = new DetailsAdapter(this, detail, R.color.categoryHotels);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // details_list.xml file.
        ListView listView = (ListView) findViewById(R.id.list);

        // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
        // {@link ListView} will display list items for each word in the list of hotels.
        // Do this by calling the setAdapter method on the {@link ListView} object and pass in
        // 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.
        listView.setAdapter(adapter);
    }
}
