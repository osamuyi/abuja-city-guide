package com.example.android.abujacityguide;

public class Details {

    //Default details
    private String mDetailName;

    //More Information about the event/location
    private String mMoreInfo;

    // Image resource ID for the word
    private int mImageResourceId = NO_IMAGE_PROVIDED;

    // Constant value that represents no image was provided for this word
    private static final int NO_IMAGE_PROVIDED = 0;

    public Details(String detailName, String moreInfo) {
        mMoreInfo = moreInfo;
        mDetailName = detailName;

    }

    public Details(String detailName, String moreInfo, int imageResourceId) {
        mDetailName = detailName;
        mMoreInfo = moreInfo;
        mImageResourceId = imageResourceId;
    }

    public String getDetailName() {
        return mDetailName;
    }

    public String getMoreInfo() {
        return mMoreInfo;
    }

    public int getImageResourceId() { return mImageResourceId; }

    public boolean hasImage() { return mImageResourceId != NO_IMAGE_PROVIDED; }

}
